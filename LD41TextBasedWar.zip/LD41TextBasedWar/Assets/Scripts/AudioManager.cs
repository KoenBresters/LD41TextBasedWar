﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class AudioManager : MonoBehaviour {

    public static AudioManager current;
    private string music = "-1";
    public string Music { get { return music; } set
        {
            if (music == value)
                return;
            if (music == "-1")
                Play(value);
            else if (value == "-1")
                Stop(music);
            else
            {
                Stop(music);
                Play(value);
            }

            music = value;
        } }
	public class Sound
    {
        public AudioClip clip;
        [Range(0f, 1f)]
        public float volume;
        [Range(.1f, 3f)]
        public float pitch;
        public bool loop;
        [HideInInspector]
        public AudioSource source;
        public Sound()
        {

        }
        public Sound(SerializeSound serializeSound)
        {
            clip = serializeSound.clip;
            volume = serializeSound.volume;
            pitch = serializeSound.pitch;
            loop = serializeSound.loop;
        }
    }
    [System.Serializable]
    public class SerializeSound : Sound
    {
        public string name = "name";
    }
    [SerializeField]
    private SerializeSound[] sounds;
    private Dictionary<string, Sound> soundDict;

    private void Awake()
    {
        if(current == null)
        {
            DontDestroyOnLoad(gameObject);
            current = this;
        }
        else
        {
            Destroy(this);
            return;
        }
        soundDict = new Dictionary<string, Sound>();
        foreach (SerializeSound i in sounds)
        {
            Sound a = new Sound(i);
            a.source = gameObject.AddComponent<AudioSource>();
            a.source.clip = a.clip;
            a.source.volume = a.volume;
            a.source.pitch = a.pitch;
            a.source.loop = a.loop;
            soundDict.Add(i.name, a);
        }
    }

    public void Play(string name)
    {
        Sound a;
        if (!soundDict.TryGetValue(name, out a))
        {
            Debug.LogWarning("the audio name " + name + " was incorrect");
            return;
        }
        a.source.Play();
    }

    public void Stop(string name)
    {
        Sound a;
        if (!soundDict.TryGetValue(name, out a))
        {
            Debug.LogWarning("the audio name " + name + " was incorrect");
            return;
        }
        a.source.Stop();
    }

    public void Stop(string name, float seconds)
    {
        StartCoroutine(stopSlow(name, seconds));
    }

    public void Transition(string name, string secondName, float seconds)
    {
        StartCoroutine(slowTransition(name, secondName, seconds));
    }

    private IEnumerator stopSlow(string name, float seconds)
    {
        Sound s = soundDict[name];
        float startMoment = Time.time;
        float stopMoment = Time.time + seconds;
        while(stopMoment > Time.time)
        {
            s.source.volume = Mathf.Lerp(0, 1, (Time.time-stopMoment)/seconds);
            yield return new WaitForEndOfFrame();
        }
        s.source.Stop();
        s.source.volume = s.volume;
    }

    private IEnumerator slowTransition(string name, string secondName, float seconds)
    {
        yield return StartCoroutine(stopSlow(name, seconds));
        Play(secondName);
    }

    public void stopMusicSlow(float seconds)
    {
        if (music == "-1") return;
        Stop(music, seconds);
        music = "-1";
    }
    public void transitionMusicSlow(string newMusic, float seconds)
    {
        if (newMusic == music) return;
        if(music == "-1")
        {
            Play(newMusic);
            return;
        }
        slowTransition(music, newMusic, seconds);
        music = "-1";
    }
}
