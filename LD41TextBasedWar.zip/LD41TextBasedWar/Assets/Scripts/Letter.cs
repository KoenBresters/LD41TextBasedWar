﻿using System;
using UnityEngine;

public class Letter : MonoBehaviour {

    public int team;
    public GameObject deathParticle;
    public Letter target = null;
    // can be null for some letters
    public Animator anim;
    public char letter;
    public float health;
    public float max_health;
    public Rigidbody2D rb;
    public float viewRange;
    public Vector2 moveTo = Vector2.zero;
    private AbsType type = null;
    private Color color = Color.red;
    public ParticleSystem particle;

	// Use this for initialization
	void Awake () {
        type = getLetterType(letter);
	}
	
    public void Damage(float amount, Letter by)
    {
        target = by;
        health -= amount;
        AudioManager.current.Play("Hit");
    }
    
    // Update is called once per frame
	void Update () {
        if(type != null)
            type.Tick();
        if (health <= 0f)
        {
            if(type != null)
                type.OnDeath();
            else
            {
                PlayerMove.current.LevelOverThing.SetBool("Go", true);
                return;
            }

            AudioManager.current.Play("Death");
            Destroy(gameObject);
            ParticleSystem p = Instantiate(deathParticle, transform.position, Quaternion.identity).GetComponent<ParticleSystem>();
            ParticleSystem.MainModule m = p.main;
            if(GetComponent<SpriteRenderer>())
                m.startColor = GetComponent<SpriteRenderer>().color;
            p.Play();
        }
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (type != null && collision.gameObject.GetComponent<Letter>() != null)
        {
            type.OnCollision(collision.gameObject.GetComponent<Letter>());
        }
            
    }

    public abstract class AbsType
    {
        public Letter owner = null;
        public float speed = 1f;
        public float damage_multiplier = 1f;
        public virtual void Tick()
        {
            if (owner.target != null)
            {
                DoAttackThings();
            }
            else if (owner.moveTo != Vector2.zero)
            {
                moveTo(owner.moveTo);
                if (Vector2.Distance(owner.moveTo, owner.transform.position) < 1f)
                    owner.moveTo = Vector2.zero;
            }
            else
            {
                retarget();
            }
        }
        public abstract AbsType init(Letter owner);
        public virtual void moveTo(Vector2 position)
        {
            owner.rb.AddForce(((Vector3)position - owner.transform.position).normalized * speed, ForceMode2D.Force);
        }
        public virtual void OnCollision(Letter with)
        {

        }
        public abstract void DoAttackThings();


        public virtual void setColor(Color col)
        {
            owner.GetComponent<SpriteRenderer>().color = col;
        }

        public virtual void OnDeath()
        {

        }

        public void retarget()
        {
            Collider2D[] l = Physics2D.OverlapCircleAll(owner.transform.position, owner.viewRange);
            Letter closest = null;
            float distance = 1000000f;
            foreach(Collider2D c in l)
            {
                Letter let = c.GetComponent<Letter>();
                if(let && let.team != owner.team && Vector2.Distance(let.transform.position, owner.transform.position) < distance)
                {
                    closest = let;
                    distance = Vector2.Distance(let.transform.position, owner.transform.position);
                }
            }

            owner.target = closest;
        }
    }

    private AbsType getLetterType(char l)
    {
        switch (l)
        {
            case 'A':
                return new A().init(this);
            case 'B':
                return new B().init(this);
            case 'D':
                return new D().init(this);
            case 'O':
                return new O().init(this);
            case 'T':
                return new T().init(this);
            case 'V':
                return new V().init(this);
            case 'E':
                return new E().init(this);
            case 'X':
                return new X().init(this);
            case 'W':
                return new W().init(this);
        }
        return null;
    }

    public class A : AbsType
    {
        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 10f;
            return this;
        }

        public override void OnCollision(Letter with)
        {
            if (with == owner.target)
            {
                owner.target.Damage(30f, owner);
                owner.target.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * 10f, ForceMode2D.Impulse);
            }
        }

        public override void moveTo(Vector2 position)
        {
            owner.rb.AddForce(((Vector3)position - owner.transform.position).normalized * speed, ForceMode2D.Force);
            owner.transform.up = ((Vector3)position - owner.transform.position).normalized;
        }

        public override void DoAttackThings()
        {
            moveTo(owner.target.transform.position);
        }
    }

    class V : A
    {
        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 20f;
            return this;
        }

        public override void OnCollision(Letter with)
        {
            if (with == owner.target)
            {
                owner.target.Damage(60f, owner);
                owner.target.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * 10f, ForceMode2D.Impulse);
            }
        }

        public override void moveTo(Vector2 position)
        {
            owner.rb.AddForce(((Vector3)position - owner.transform.position).normalized * speed, ForceMode2D.Force);
            owner.transform.up = -((Vector3)position - owner.transform.position).normalized;

        }
    }
    public class O : AbsType
    {
        private static float attack_time = 3f;
        private float attack_timer = 0f;

        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 5f;
            attack_timer = UnityEngine.Random.Range(0f, attack_time);
            return this;
        }

        public override void DoAttackThings()
        {
            
        }

        public override void Tick()
        {
            if(owner.anim.GetBool("isLarge"))
                owner.anim.SetBool("isLarge", false);
            if (owner.target != null)
            {
                owner.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * speed, ForceMode2D.Force);
                if (Vector2.Distance(owner.transform.position, owner.target.transform.position) < 3f)
                {
                    attack_timer += Time.deltaTime;
                    if (attack_timer > attack_time)
                    {
                        attack_timer = 0f;
                        owner.anim.SetBool("isLarge", true);
                        Collider2D[] col = Physics2D.OverlapCircleAll(owner.transform.position, 3f);
                        foreach (Collider2D c in col)
                        {
                            Letter l = c.GetComponent<Letter>();
                            if (l != null && l.team != owner.team)
                            {
                                l.Damage(10f, owner); ;
                                l.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * 20f, ForceMode2D.Impulse);
                            }
                        }
                    }
                }
            }
            else if (owner.moveTo != Vector2.zero)
            {
                moveTo(owner.moveTo);
            }else
            {
                retarget();
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, viewRange);
    }

    public void setColor(Color col)
    {
        if (type != null)
        {
            type.setColor(col);
            color = col;
        }
    }

    public Color getColor()
    {
        return color;
    }

    public class D : AbsType
    {
        private static float grow_time = 20f;
        private float grow_timer = 0f;
        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 10f;
            return this;
        }

        public override void moveTo(Vector2 position)
        {
            owner.rb.AddForce(((Vector3)position - owner.transform.position).normalized * speed, ForceMode2D.Force);
            owner.transform.up = ((Vector3)position - owner.transform.position).normalized;
        }

        public override void DoAttackThings()
        {
            owner.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * -speed, ForceMode2D.Force);
            owner.transform.up = (owner.target.transform.position - owner.transform.position).normalized;
        }

        public override void Tick()
        {
            base.Tick();
            grow_timer += Time.deltaTime;
            if(grow_timer > grow_time)
            {
                Letter l = Instantiate(PlayerMove.current.costs['B'].LetterObject, owner.transform.position, Quaternion.identity).GetComponent<Letter>();
                l.team = owner.team;
                l.setColor(owner.getColor());
                Destroy(owner.gameObject);
            }
        }
    }
    public class B : AbsType
    {
        private static float attack_time = 3f;
        private float attack_timer = 0f;

        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 5f;
            attack_timer = UnityEngine.Random.Range(0f, attack_time);
            return this;
        }

        public override void DoAttackThings()
        {

        }

        public override void OnDeath()
        {
            Letter l = Instantiate(PlayerMove.current.costs['D'].LetterObject, owner.transform.position, Quaternion.identity).GetComponent<Letter>();
            l.team = owner.team;
            l.setColor(owner.getColor());
            l = Instantiate(PlayerMove.current.costs['D'].LetterObject, owner.transform.position, Quaternion.identity).GetComponent<Letter>();
            l.team = owner.team;
            l.setColor(owner.getColor());
        }

        public override void Tick()
        {
            if (owner.target != null)
            {
                owner.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * speed, ForceMode2D.Force);
                if (Vector2.Distance(owner.transform.position, owner.target.transform.position) < 3f)
                {
                    attack_timer += Time.deltaTime;
                    if (attack_timer > attack_time)
                    {
                        attack_timer = 0f;
                        owner.target.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * 20f, ForceMode2D.Impulse);
                        owner.target.Damage(5f, owner);
                    }
                }
            }
            else if (owner.moveTo != Vector2.zero)
            {
                moveTo(owner.moveTo);
            }
            else
            {
                retarget();
            }
        }
    }

    public class T : AbsType
    {
        private static float attack_time = 3f;
        private float attack_timer = 0f;

        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 5f;
            attack_timer = UnityEngine.Random.Range(0f, attack_time);
            return this;
        }

        public override void DoAttackThings()
        {
            if (Vector2.Distance(owner.transform.position, owner.target.transform.position) < owner.viewRange)
            {
                attack_timer += Time.deltaTime;
                if (attack_timer > attack_time)
                {
                    attack_timer = 0f;
                    owner.target.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * 5f, ForceMode2D.Impulse);
                    Instantiate(PlayerMove.current.stripePrefab, ((Vector2)owner.transform.position) + Vector2.up, Quaternion.identity).GetComponent<StripeProjectile>().
                        init(owner.getColor(), owner.team, owner, 40f, (owner.transform.position - owner.target.transform.position).normalized, 20f, 1f) ;
                }
            }
        }

        public override void moveTo(Vector2 position)
        {
            
        }
    }

    public class E : AbsType
    {
        private static float attack_time = .5f;
        private float attack_timer = 0f;

        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 5f;
            attack_timer = UnityEngine.Random.Range(0f, attack_time);
            return this;
        }

        public override void DoAttackThings()
        {
            owner.transform.right = (owner.target.transform.position - owner.transform.position).normalized;
            if (Vector2.Distance(owner.transform.position, owner.target.transform.position) < owner.viewRange)
            {
                attack_timer += Time.deltaTime;
                if (attack_timer > attack_time)
                {
                    attack_timer = 0f;
                    Instantiate(PlayerMove.current.stripePrefab, ((Vector2)owner.transform.position), Quaternion.identity).GetComponent<StripeProjectile>().
                        init(owner.getColor(), owner.team, owner, 20f, (owner.transform.position - owner.target.transform.position).normalized, 40f, .5f);
                }
            }else
            {
                moveTo(owner.target.transform.position);
            }
        }
    }

    public class X : AbsType
    {

        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 5f;
            return this;
        }

        public override void DoAttackThings()
        {

        }

        public override void Tick()
        {
            if (owner.target != null)
            {
                owner.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * speed, ForceMode2D.Force);
                if (Vector2.Distance(owner.transform.position, owner.target.transform.position) < 7f)
                {
                    owner.GetComponent<Collider2D>().enabled = false;
                    Collider2D[] col = Physics2D.OverlapCircleAll(owner.transform.position, 7f);
                    if(!owner.particle.isPlaying)
                        owner.particle.Play();
                    foreach (Collider2D c in col)
                    {
                        Letter l = c.GetComponent<Letter>();
                        if (l != null && l.team != owner.team)
                        {
                            l.Damage(50f*Time.deltaTime, owner);
                            l.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * -15f, ForceMode2D.Force);
                        }
                    }
                    owner.rb.AddTorque(10f, ForceMode2D.Force);
                }else
                {
                    owner.GetComponent<Collider2D>().enabled = true;
                }
            }
            else if (owner.moveTo != Vector2.zero)
            {
                if (owner.particle.isPlaying)
                    owner.particle.Stop();
                moveTo(owner.moveTo);
                owner.GetComponent<Collider2D>().enabled = true;
            }
            else
            {
                if (owner.particle.isPlaying)
                    owner.particle.Stop();
                retarget();
                owner.GetComponent<Collider2D>().enabled = true;
            }
        }
    }

    public class W : AbsType
    {
        private static float attack_time = 2f;
        private float attack_timer = 0f;

        public override AbsType init(Letter owner)
        {
            this.owner = owner;
            speed = 5f;
            attack_timer = UnityEngine.Random.Range(0f, attack_time);
            return this;
        }

        public override void DoAttackThings()
        {
            owner.transform.up = -(owner.target.transform.position - owner.transform.position).normalized;
            if (Vector2.Distance(owner.transform.position, owner.target.transform.position) < owner.viewRange)
            {
                attack_timer += Time.deltaTime;
                if (attack_timer > attack_time)
                {
                    attack_timer = 0f;
                    owner.target.rb.AddForce((owner.target.transform.position - owner.transform.position).normalized * 20f, ForceMode2D.Impulse);
                    Letter l = Instantiate(PlayerMove.current.costs['V'].LetterObject, owner.transform.TransformPoint(new Vector3(2.4f, 0f, 0f)),
                        owner.transform.rotation).GetComponent<Letter>();
                    l.team = owner.team;
                    l.target = owner.target;
                    l.setColor(owner.getColor());
                    l = Instantiate(PlayerMove.current.costs['V'].LetterObject, owner.transform.TransformPoint(new Vector3(-2.4f, 0f, 0f)),
                        owner.transform.rotation).GetComponent<Letter>();
                    l.team = owner.team;
                    l.target = owner.target;
                    l.setColor(owner.getColor());
                }
            }
            else
            {
                moveTo(owner.target.transform.position);
            }
        }
    }
}
