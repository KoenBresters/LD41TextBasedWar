﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class PlayerMove : MonoBehaviour {

    public float speed = 1f;
    public float Ink;
    public Image inkBar;
    public Image health_bar;
    public Text inkText;
    public Text maxInkText;
    public Text enterText;
    public Text enterCostText;
    public Text upgradeButtonText;
    public Dictionary<char, LetterKey> costs;
    public string text;
    public LetterKey[] keys;
    public Letter health_manager;
    public Color color;
    public GameObject stripePrefab;
    public int ink_pump_type_index = 0;
    public InkPumpType[] inkPumpTypes;
    private List<Letter> selected;
    public Animator LevelOverThing;
    [System.Serializable]
    public class LetterKey
    {
        public KeyCode key;
        public float cost;
        public char character;
        public GameObject LetterObject;
    }

    [System.Serializable]
    public class InkPumpType
    {
        public float ink_per_second;
        public float max_ink;
        public float cost;
    }

    public static PlayerMove current = null;

    public void Upgrade()
    {
        if(ink_pump_type_index != inkPumpTypes.Length-1 && Ink >= inkPumpTypes[ink_pump_type_index+1].cost)
        {
            ink_pump_type_index++;
            Ink -= inkPumpTypes[ink_pump_type_index].cost;
            if (ink_pump_type_index != inkPumpTypes.Length - 1)
                maxInkText.text = "max ink: " + ((int)inkPumpTypes[ink_pump_type_index].max_ink).ToString();
            else
                maxInkText.text = "MAX";
            upgradeButtonText.text = "Upgrade Cost: " + ((int)inkPumpTypes[ink_pump_type_index+1].cost).ToString();
        }
    }

    public void Reset()
    {
        SceneManager.LoadScene(0);
    }

    public void Quit()
    {
        Application.Quit();
    }

    private void Awake()
    {
        current = this;
    }

    private void Start()
    {
        costs = new Dictionary<char, LetterKey>();
        selected = new List<Letter>();
        foreach (LetterKey i in keys)
        {
            costs.Add(i.character, i);
        }
    }

    private void Update()
    {
        if (Input.GetMouseButton(1))
        {
            Vector2 point = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            foreach(Collider2D c in Physics2D.OverlapCircleAll(point, .25f))
            {
                Letter l = c.GetComponent<Letter>();
                if(l != null && l != health_manager && l.team == health_manager.team && !selected.Contains(l))
                {
                    l.setColor(Color.yellow);
                    selected.Add(l);
                }
            }  
        }

        if (Input.GetMouseButton(2))
        {
            Vector2 point = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            foreach (Collider2D c in Physics2D.OverlapCircleAll(point, .25f))
            {
                Letter l = c.GetComponent<Letter>();
                if (l != null && l != health_manager && l.team == health_manager.team && selected.Contains(l))
                {
                    l.setColor(color);
                    l.moveTo = Vector2.zero;
                    selected.Remove(l);
                }
            }
        }

        if (Input.GetMouseButtonDown(0))
        {
            Vector2 point = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            bool has_found = false;
            foreach (Collider2D c in Physics2D.OverlapCircleAll(point, 1f))
            {
                Letter l = c.GetComponent<Letter>();
                if (l != null && l.team != health_manager.team)
                {
                    foreach (Letter i in selected)
                    {
                        if (i != null)
                            i.target = l;
                    }
                    has_found = true;
                    break;
                }
            }
            if (!has_found)
            {
                foreach (Letter i in selected)
                {
                    if (i == null)
                        continue;
                    i.target = null;
                    i.moveTo = point;
                }
            }
        }
        if (Input.GetKeyDown(KeyCode.Delete))
        {
            foreach(Letter l in selected)
            {
                if (l == null)
                    continue;
                l.setColor(color);
                l.moveTo = Vector2.zero;
            }
            selected.Clear();
        }

        if (Input.GetKey(KeyCode.UpArrow))
            transform.position += (Vector3)(Vector2.up * speed * Time.deltaTime);
        if (Input.GetKey(KeyCode.DownArrow))
            transform.position += (Vector3)(Vector2.down * speed * Time.deltaTime);
        if (Input.GetKey(KeyCode.LeftArrow))
            transform.position += (Vector3)(Vector2.left * speed * Time.deltaTime);
        if (Input.GetKey(KeyCode.RightArrow))
            transform.position += (Vector3)(Vector2.right * speed * Time.deltaTime);

        foreach (LetterKey i in keys)
        {
            if (Input.GetKeyDown(i.key))
                text = text + i.character;
        }
        if (text.Length != 0 && Input.GetKeyDown(KeyCode.Backspace))
            text = text.Substring(0, text.Length-1);
        if (Input.GetKeyDown(KeyCode.Return))
        {
            float y = 0f;
            foreach (char c in text)
            {
                y += costs[c].cost;
            }
            if(y <= Ink)
            {
                useText();
                Ink -= y;
                text = "";
            }
        }
        InkPumpType ipt = inkPumpTypes[ink_pump_type_index];
        Ink += ipt.ink_per_second * Time.deltaTime;
        if (Ink > ipt.max_ink)
            Ink = ipt.max_ink;

        inkBar.fillAmount = Ink / ipt.max_ink;
        health_bar.fillAmount = health_manager.health / health_manager.max_health;
        enterText.text = text;
        inkText.text = "ink: " + ((int)Ink).ToString();
        float x = 0f;
        foreach (char c in text)
        {
            x += costs[c].cost;
        }
        enterCostText.text = "cost: " + x.ToString();
    }

    private void useText()
    {
        foreach(char c in text)
        {
            LetterKey k = costs[c];
            GameObject g = Instantiate(k.LetterObject, new Vector3(transform.position.x, transform.position.y, 0f), Quaternion.identity);
            g.GetComponent<Letter>().team = health_manager.team;
            g.GetComponent<Letter>().setColor(color);
            g.GetComponent<Rigidbody2D>().velocity = Random.insideUnitCircle * 10f;
        }
    }
}
