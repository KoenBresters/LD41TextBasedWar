﻿using UnityEngine;

public class SceneMusic : MonoBehaviour {

    public bool stop;
    public string music;
    public bool slow;
    public float seconds;

    // Use this for initialization
    void Start() {
        if (!stop)
            if (!slow)
                AudioManager.current.Music = music;
            else
                AudioManager.current.transitionMusicSlow(music, seconds);
        else if (slow)
            AudioManager.current.stopMusicSlow(seconds);
        else
            AudioManager.current.Music = "-1";
        Destroy(this);
    }
}
