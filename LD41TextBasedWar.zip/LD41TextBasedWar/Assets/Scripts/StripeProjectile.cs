﻿using UnityEngine;

public class StripeProjectile : MonoBehaviour {
    public int team;
    public Letter owner;
    public float hit_damage;

    public void init(Color c, int t, Letter shotBy, float damage, Vector2 direction, float force, float scale)
    {
        team = t;
        GetComponent<SpriteRenderer>().color = c;
        owner = shotBy;
        hit_damage = damage;
        transform.right = direction;
        GetComponent<ConstantForce2D>().relativeForce = new Vector2(-force, 0f);
        transform.localScale = transform.localScale * scale;
        Physics2D.IgnoreCollision(GetComponent<BoxCollider2D>(), shotBy.GetComponent<Collider2D>());
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Letter l = collision.gameObject.GetComponent<Letter>();
        if(l && l.team != team) 
            l.Damage(hit_damage, owner);
        Destroy(gameObject);
    }
}
