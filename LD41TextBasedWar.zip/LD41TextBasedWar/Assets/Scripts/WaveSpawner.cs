﻿using UnityEngine;
using UnityEngine.UI;

public class WaveSpawner : MonoBehaviour {
    [System.Serializable]
    public class Wave {
        public GameObject letters;
        public float time;
    }
    public Wave[] waves;
    public int wave_index = -1;
    public Text timeText;
    public Text waveText;
    public Text waveText2;
    public Text gameOverText;
    private float timer = 20f;
    private bool is_waiting = true;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        timer -= Time.deltaTime;
        bool b = false;
        if (!is_waiting)
        {
            b = false;
            foreach (Letter l in FindObjectsOfType<Letter>())
            {
                if (l.team != 0)
                    b = true;
            }

            if (!b)
                timer = 0f;
        }

        if (timer <= 0f)
        {
            if (is_waiting)
            {
                wave_index++;
                if (wave_index == waves.Length) {
                    gameOverText.text = "You Won";
                    PlayerMove.current.LevelOverThing.SetBool("Go", true);
                    waveText2.text = "You Survived All Waves";
                    wave_index--;
                    return;
                }

                waveText.text = "Wave: " + (wave_index+1).ToString();
                waveText2.text = "Survived Waves: " + (wave_index + 1).ToString();
                Instantiate(waves[wave_index].letters);
                timer = waves[wave_index].time;


            }
            else
            {
                if (b)
                {
                    PlayerMove.current.LevelOverThing.SetBool("Go", true);
                }

                timer = 20f;
                
            }
            is_waiting = !is_waiting;
        }
        if (is_waiting)
            timeText.text = "Next Wave: " + ((int)timer).ToString();
        else
            timeText.text = "Time Left: " + ((int)timer).ToString();

    }
}
